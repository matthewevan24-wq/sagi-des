import React, { useEffect, useRef, useState } from "react";
import { Play, RotateCcw, Zap, Palette, ListTodo, Plus, Trash2, Trophy, Flame, Timer, Check, Sparkles, MousePointerClick } from "lucide-react";

type Todo = { id: string; text: string; done: boolean };
type ScoreState = { bestClick: number; colorScore: number; colorStreak: number; bestStreak: number };
type Tab = "klik" | "warna" | "todo";

const emptyScores: ScoreState = { bestClick: 0, colorScore: 0, colorStreak: 0, bestStreak: 0 };

async function callApi(action: string, args: Record<string, unknown>) {
  const res = await fetch("actions", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ action, args }),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || json.error) throw new Error(json.error || `Gagal memanggil ${action}`);
  return json.data;
}

function randomHex() {
  return "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0").toUpperCase();
}
function makeQuestion() {
  const target = randomHex();
  const set = new Set([target]);
  while (set.size < 4) set.add(randomHex());
  const options = Array.from(set);
  for (let i = options.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [options[i], options[j]] = [options[j], options[i]];
  }
  return { target, options };
}

export default function App() {
  const [tab, setTab] = useState<Tab>("klik");
  const [scores, setScores] = useState<ScoreState>(emptyScores);
  const [stateId, setStateId] = useState<string | null>(null);
  const [todos, setTodos] = useState<Todo[]>([]);
  const [loading, setLoading] = useState(true);
  const [syncNote, setSyncNote] = useState("");
  const [saving, setSaving] = useState(false);

  // Klik Cepat
  const [clickPhase, setClickPhase] = useState<"idle" | "running" | "done">("idle");
  const [clicks, setClicks] = useState(0);
  const [timeLeft, setTimeLeft] = useState(10);
  const [clickPop, setClickPop] = useState(0);
  const timerRef = useRef<number | null>(null);

  // Tebak Warna
  const [question, setQuestion] = useState(() => makeQuestion());
  const [picked, setPicked] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<"idle" | "correct" | "wrong">("idle");
  const [feedbackMsg, setFeedbackMsg] = useState("Pilih kotak yang warnanya sama dengan kode di atas.");

  // To-Do
  const [newTodo, setNewTodo] = useState("");
  const [todoError, setTodoError] = useState("");

  const persistScores = async (next: ScoreState, currentId: string | null) => {
    setSaving(true);
    try {
      if (currentId) {
        await callApi("records.replace", { collection: "sagi_des_scores", id: currentId, value: next });
      } else {
        const created = await callApi("records.create", { collection: "sagi_des_scores", value: next, idempotency_key: `sagi-scores-${Date.now()}` });
        if (created?.id) setStateId(created.id);
      }
      setSyncNote("Tersimpan ✓");
    } catch {
      setSyncNote("Belum tersimpan — coba lagi nanti.");
    } finally { setSaving(false); }
  };

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const scoreData = await callApi("records.list", { collection: "sagi_des_scores" });
        const todoData = await callApi("records.list", { collection: "sagi_des_todos" });
        if (!alive) return;
        if (scoreData?.records?.[0]) {
          setStateId(scoreData.records[0].id);
          setScores({ ...emptyScores, ...scoreData.records[0].value });
        }
        const mapped = (todoData?.records || []).map((r: any) => ({ id: r.id, text: String(r.value?.text || ""), done: Boolean(r.value?.done) }));
        setTodos(mapped.filter((t: Todo) => t.text));
        setSyncNote("Data dimuat ✓");
      } catch {
        if (alive) setSyncNote("Mode offline — skor & to-do belum tersimpan.");
      } finally { if (alive) setLoading(false); }
    })();
    return () => { alive = false; };
  }, []);

  useEffect(() => () => { if (timerRef.current) window.clearInterval(timerRef.current); }, []);

  const startClick = () => {
    if (timerRef.current) window.clearInterval(timerRef.current);
    setClicks(0); setTimeLeft(10); setClickPhase("running"); setClickPop(0);
    timerRef.current = window.setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          if (timerRef.current) window.clearInterval(timerRef.current);
          setClickPhase("done");
          return 0;
        }
        return t - 1;
      });
    }, 1000);
  };

  const handleClickGame = () => {
    if (clickPhase !== "running") return;
    const next = clicks + 1;
    setClicks(next); setClickPop(next);
    if (next > scores.bestClick) {
      const updated = { ...scores, bestClick: next };
      setScores(updated);
      persistScores(updated, stateId);
    }
  };

  const resetClick = () => {
    if (timerRef.current) window.clearInterval(timerRef.current);
    setClickPhase("idle"); setClicks(0); setTimeLeft(10);
  };

  const chooseColor = (color: string) => {
    if (feedback === "correct") return;
    setPicked(color);
    if (color === question.target) {
      const streak = scores.colorStreak + 1;
      const updated = { ...scores, colorScore: scores.colorScore + 1, colorStreak: streak, bestStreak: Math.max(scores.bestStreak, streak) };
      setScores(updated); setFeedback("correct"); setFeedbackMsg("Gas! Bener banget 🔥");
      persistScores(updated, stateId);
    } else {
      const updated = { ...scores, colorStreak: 0 };
      setScores(updated); setFeedback("wrong"); setFeedbackMsg("Yah, meleset. Coba lagi, masih bisa!");
      persistScores(updated, stateId);
    }
  };

  const nextQuestion = () => { setQuestion(makeQuestion()); setPicked(null); setFeedback("idle"); setFeedbackMsg("Pilih kotak yang warnanya sama dengan kode di atas."); };

  const addTodo = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const text = newTodo.trim();
    if (!text) { setTodoError("Tulis dulu tugasnya, jangan kosong dong."); return; }
    if (text.length > 120) { setTodoError("Tugasnya kepanjangan, max 120 karakter ya."); return; }
    setTodoError(""); setNewTodo(""); setSaving(true);
    try {
      const created = await callApi("records.create", { collection: "sagi_des_todos", value: { text, done: false }, idempotency_key: `todo-${Date.now()}-${Math.random().toString(36).slice(2)}` });
      if (created?.id) setTodos((prev) => [...prev, { id: created.id, text, done: false }]);
      setSyncNote("Tugas tersimpan ✓");
    } catch {
      setSyncNote("Tugas belum tersimpan — coba lagi.");
      setNewTodo(text);
    } finally { setSaving(false); }
  };

  const toggleTodo = async (todo: Todo) => {
    const next = { ...todo, done: !todo.done };
    setTodos((prev) => prev.map((t) => (t.id === todo.id ? next : t)));
    try { await callApi("records.replace", { collection: "sagi_des_todos", id: todo.id, value: { text: todo.text, done: next.done } }); }
    catch { setSyncNote("Perubahan belum tersimpan."); }
  };

  const deleteTodo = async (id: string) => {
    const before = todos;
    setTodos((prev) => prev.filter((t) => t.id !== id));
    try { await callApi("records.delete", { collection: "sagi_des_todos", id }); }
    catch { setTodos(before); setSyncNote("Gagal hapus, coba lagi."); }
  };

  const remaining = todos.filter((t) => !t.done).length;
  const doneCount = todos.length - remaining;
  const totalScore = scores.bestClick + scores.colorScore + doneCount;

  const tabs: { id: Tab; label: string; icon: React.ReactNode; desc: string }[] = [
    { id: "klik", label: "Klik Cepat", icon: <MousePointerClick size={18} />, desc: "10 detik" },
    { id: "warna", label: "Tebak Warna", icon: <Palette size={18} />, desc: "HEX hunter" },
    { id: "todo", label: "To-Do Cepat", icon: <ListTodo size={18} />, desc: `${remaining} sisa` },
  ];

  return (
    <div data-safe-area-inset-root style={{ boxSizing: "border-box", paddingTop: "var(--safe-area-inset-top)", minHeight: "100vh", background: "var(--bg)", color: "var(--text)" }} className="overflow-x-clip">
      <div className="mx-auto max-w-[880px] px-4 pb-8 sm:px-6">
        {/* HEADER */}
        <header className="pt-5 sm:pt-8">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full border border-[var(--line)] bg-[var(--surface)] px-3 py-1 text-[11px] font-bold tracking-[0.18em] uppercase"><Sparkles size={13} className="text-[var(--primary)]" /> sagi-des</div>
              <h1 className="mt-4 text-[clamp(28px,7vw,52px)] font-bold leading-[0.95] tracking-tight">Experiment <span className="text-[var(--primary)]">#2</span><br />Mini Game<br />Interaktif.</h1>
              <p className="mt-3 max-w-[560px] text-[15px] leading-relaxed text-[var(--muted)]">Repo belajar dan experiment untuk project sagi-des — Experiment #2. Main santai, latihan refleks, mata, sama manajemen tugas.</p>
            </div>
            <div className="hidden shrink-0 animate-floaty rounded-3xl bg-[var(--primary)] px-4 py-3 text-center text-[var(--primary-ink)] shadow-xl sm:block"><div className="text-[11px] font-bold uppercase tracking-widest">Skor total</div><div className="mono text-4xl font-bold">{totalScore}</div></div>
          </div>

          <div className="mt-5 flex items-center justify-between gap-3 rounded-2xl border border-[var(--line)] bg-[var(--surface)] p-3 sm:hidden">
            <span className="flex items-center gap-2 text-sm font-bold"><Trophy size={18} className="text-[var(--primary)]" /> Skor total gabungan</span>
            <span className="mono rounded-xl bg-[var(--primary)] px-3 py-1 text-xl font-bold text-[var(--primary-ink)]">{totalScore}</span>
          </div>
          <div className="mt-3 hidden items-center gap-2 text-xs text-[var(--muted)] sm:flex"><span className="h-2 w-2 rounded-full bg-[var(--primary)]" /> {loading ? "Memuat progres kamu…" : syncNote} {saving && <span>· menyimpan…</span>}</div>
        </header>

        {/* TAB NAV */}
        <nav aria-label="Pilih mini game" className="sticky top-[var(--safe-area-inset-top)] z-20 mt-6 rounded-2xl border border-[var(--line)] bg-[var(--surface)] p-1.5 shadow-lg" data-safe-area-sticky-top>
          <div className="grid grid-cols-3 gap-1.5">
            {tabs.map((t) => (
              <button key={t.id} onClick={() => setTab(t.id)} aria-pressed={tab === t.id} className={`rounded-xl px-2 py-3 text-left transition ${tab === t.id ? "tab-active shadow" : "hover:bg-[var(--surface-2)]"}`}>
                <span className="flex items-center gap-1.5 text-[13px] font-bold sm:text-[15px]">{t.icon}<span className="overflow-wrap-anywhere [overflow-wrap:anywhere]">{t.label}</span></span>
                <span className={`mt-1 block text-[11px] ${tab === t.id ? "opacity-70" : "text-[var(--muted)]"}`}>{t.desc}</span>
              </button>
            ))}
          </div>
        </nav>

        <main className="mt-4">
          {/* GAME 1 */}
          {tab === "klik" && (
            <section className="overflow-hidden rounded-[28px] border border-[var(--line)] bg-[var(--surface)] p-5 sm:p-7">
              <div className="flex items-center justify-between gap-3"><div><p className="text-xs font-bold uppercase tracking-[0.18em] text-[var(--primary)]">Game 01 — Refleks</p><h2 className="mt-1 text-3xl font-bold">Klik Cepat</h2></div><span className="rounded-full bg-[var(--surface-2)] px-3 py-1 text-xs font-bold">10 detik doang!</span></div>
              <p className="mt-2 text-sm text-[var(--muted)]">Klik tombol gede di bawah sebanyak-banyaknya. Jangan sampai jempol kram.</p>

              <div className="mt-6 grid grid-cols-3 gap-2 text-center">
                <div className="rounded-2xl bg-[var(--surface-2)] p-3"><div className="flex items-center justify-center gap-1 text-[11px] text-[var(--muted)]"><Timer size={13} /> Timer</div><div className="mono mt-1 text-3xl font-bold">{timeLeft}<span className="text-sm">s</span></div></div>
                <div className="rounded-2xl bg-[var(--surface-2)] p-3"><div className="flex items-center justify-center gap-1 text-[11px] text-[var(--muted)]"><Zap size={13} /> Skor</div><div className="mono mt-1 text-3xl font-bold text-[var(--primary)]">{clicks}</div></div>
                <div className="rounded-2xl bg-[var(--surface-2)] p-3"><div className="flex items-center justify-center gap-1 text-[11px] text-[var(--muted)]"><Trophy size={13} /> Best</div><div className="mono mt-1 text-3xl font-bold">{scores.bestClick}</div></div>
              </div>

              <div className="mt-5 rounded-2xl bg-[var(--bg)] p-3">
                <div className="h-2 overflow-hidden rounded-full bg-[var(--surface-2)]"><div className="h-full bg-[var(--primary)] transition-all duration-1000" style={{ width: `${timeLeft * 10}%` }} /></div>
              </div>

              <button onClick={handleClickGame} disabled={clickPhase !== "running"} className={`mt-4 w-full rounded-[24px] py-7 text-center transition active:scale-[0.98] sm:py-9 ${clickPhase === "running" ? "animate-pulse-ring bg-[var(--primary)] text-[var(--primary-ink)]" : "bg-[var(--surface-2)] text-[var(--muted)]"}`}>
                <span key={clickPop} className="animate-pop block text-[clamp(28px,8vw,44px)] font-bold leading-none">{clickPhase === "idle" ? "SIAP?" : clickPhase === "done" ? "WAKTU HABIS!" : `${clicks} KLIK!`}</span>
                <span className="mt-2 block text-sm font-semibold">{clickPhase === "running" ? "Terus klik, jangan berhenti!" : clickPhase === "done" ? `Skor kamu ${clicks} — best ${scores.bestClick}` : "Tekan MULAI dulu, baru gas"}</span>
              </button>

              <div className="mt-4 grid grid-cols-2 gap-2">
                <button onClick={startClick} className="flex items-center justify-center gap-2 rounded-2xl bg-[var(--text)] px-4 py-4 font-bold text-[var(--bg)] transition active:scale-[0.98]"><Play size={18} /> {clickPhase === "running" ? "Ulang dari awal" : "Mulai"}</button>
                <button onClick={resetClick} className="flex items-center justify-center gap-2 rounded-2xl border border-[var(--line)] px-4 py-4 font-bold transition active:scale-[0.98]"><RotateCcw size={18} /> Reset</button>
              </div>
              {clickPhase === "done" && clicks >= scores.bestClick && clicks > 0 && <p className="mt-4 rounded-xl bg-[var(--primary)]/15 px-3 py-2 text-center text-sm font-bold text-[var(--primary)]">🔥 Rekor baru! Best score kamu sekarang {scores.bestClick}.</p>}
            </section>
          )}

          {/* GAME 2 */}
          {tab === "warna" && (
            <section className="overflow-hidden rounded-[28px] border border-[var(--line)] bg-[var(--surface)] p-5 sm:p-7">
              <div className="flex items-center justify-between gap-3"><div><p className="text-xs font-bold uppercase tracking-[0.18em] text-[var(--violet)]">Game 02 — Mata jeli</p><h2 className="mt-1 text-3xl font-bold">Tebak Warna</h2></div><span className="flex items-center gap-1 rounded-full bg-[var(--surface-2)] px-3 py-1 text-xs font-bold"><Flame size={14} className="text-[var(--amber)]" /> Streak {scores.colorStreak}</span></div>
              <p className="mt-2 text-sm text-[var(--muted)]">Cocokin kode HEX ini sama kotak warna yang paling mirip. Jangan asal tebak ya.</p>

              <div className="mt-6 rounded-2xl bg-[var(--bg)] p-5 text-center">
                <div className="text-[11px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">Kode warnanya</div>
                <div className="mono mt-2 text-[clamp(36px,10vw,58px)] font-bold tracking-tight">{question.target}</div>
                <div className="mx-auto mt-3 h-3 w-40 rounded-full" style={{ background: question.target }} />
              </div>

              <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
                {question.options.map((color) => {
                  const isPicked = picked === color;
                  const isTarget = color === question.target;
                  return (
                    <button key={color} onClick={() => chooseColor(color)} aria-label={`Pilih warna ${color}`} className={`group rounded-2xl border-2 p-2 text-left transition active:scale-[0.97] ${feedback === "correct" && isTarget ? "border-[var(--primary)]" : feedback === "wrong" && isPicked ? "animate-shake border-[var(--pink)]" : "border-transparent hover:border-[var(--line)]"}`}>
                      <span className="block aspect-square w-full rounded-xl shadow-inner" style={{ background: color }} />
                      <span className="mono mt-2 block text-center text-xs font-bold text-[var(--muted)]">{feedback !== "idle" && isTarget ? color : "••••••"}</span>
                    </button>
                  );
                })}
              </div>

              <div className={`mt-4 rounded-2xl px-4 py-3 text-center text-sm font-bold ${feedback === "correct" ? "bg-[var(--primary)]/15 text-[var(--primary)]" : feedback === "wrong" ? "bg-[var(--pink)]/15 text-[var(--pink)]" : "bg-[var(--surface-2)] text-[var(--muted)]"}`} role="status">{feedbackMsg}</div>

              <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                <div className="rounded-2xl bg-[var(--surface-2)] p-3"><div className="text-[11px] text-[var(--muted)]">Skor</div><div className="mono mt-1 text-2xl font-bold text-[var(--violet)]">{scores.colorScore}</div></div>
                <div className="rounded-2xl bg-[var(--surface-2)] p-3"><div className="text-[11px] text-[var(--muted)]">Streak</div><div className="mono mt-1 text-2xl font-bold">{scores.colorStreak}</div></div>
                <div className="rounded-2xl bg-[var(--surface-2)] p-3"><div className="text-[11px] text-[var(--muted)]">Best streak</div><div className="mono mt-1 text-2xl font-bold">{scores.bestStreak}</div></div>
              </div>

              <button onClick={nextQuestion} className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-[var(--violet)] px-4 py-4 font-bold text-[#17101f] transition active:scale-[0.98]"><Sparkles size={18} /> Soal Baru</button>
            </section>
          )}

          {/* GAME 3 */}
          {tab === "todo" && (
            <section className="overflow-hidden rounded-[28px] border border-[var(--line)] bg-[var(--surface)] p-5 sm:p-7">
              <div className="flex items-center justify-between gap-3"><div><p className="text-xs font-bold uppercase tracking-[0.18em] text-[var(--cyan)]">Game 03 — Fokus</p><h2 className="mt-1 text-3xl font-bold">To-Do Cepat</h2></div><span className="rounded-full bg-[var(--surface-2)] px-3 py-1 text-xs font-bold">{remaining} sisa · {doneCount} beres</span></div>
              <p className="mt-2 text-sm text-[var(--muted)]">Tulis tugasnya, kelarin satu-satu, rasain lega-nya pas checklist semua.</p>

              <form onSubmit={addTodo} className="mt-5 flex gap-2">
                <label htmlFor="todo-input" className="sr-only">Tambah tugas baru</label>
                <input id="todo-input" value={newTodo} onChange={(e) => setNewTodo(e.target.value)} placeholder="Misal: push experiment ke GitHub…" className="min-w-0 flex-1 rounded-2xl border border-[var(--line)] bg-[var(--bg)] px-4 py-4 text-[15px] outline-none placeholder:text-[var(--muted)] focus:border-[var(--cyan)]" />
                <button type="submit" disabled={saving} className="flex shrink-0 items-center gap-1.5 rounded-2xl bg-[var(--cyan)] px-4 py-4 font-bold text-[#06222a] transition active:scale-[0.97] disabled:opacity-60"><Plus size={19} /> Tambah</button>
              </form>
              {todoError && <p className="mt-2 text-sm font-semibold text-[var(--pink)]" role="alert">{todoError}</p>}

              <div className="mt-4 space-y-2">
                {loading && <p className="rounded-2xl bg-[var(--surface-2)] p-4 text-center text-sm text-[var(--muted)]">Lagi ngambil daftar tugas…</p>}
                {!loading && todos.length === 0 && <div className="rounded-2xl border border-dashed border-[var(--line)] p-6 text-center"><ListTodo className="mx-auto text-[var(--muted)]" /><p className="mt-2 font-bold">Belum ada tugas</p><p className="mt-1 text-sm text-[var(--muted)]">Tambah satu di atas, mulai dari yang paling gampang.</p></div>}
                {todos.map((todo) => (
                  <div key={todo.id} className={`flex items-center gap-3 rounded-2xl border p-3 transition ${todo.done ? "border-[var(--line)] bg-[var(--surface-2)] opacity-70" : "border-[var(--line)] bg-[var(--bg)]"}`}>
                    <button onClick={() => toggleTodo(todo)} aria-label={todo.done ? `Batalkan ${todo.text}` : `Selesaikan ${todo.text}`} className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-2 transition ${todo.done ? "border-[var(--primary)] bg-[var(--primary)] text-[var(--primary-ink)]" : "border-[var(--line)]"}`}>{todo.done && <Check size={17} />}</button>
                    <span className={`min-w-0 flex-1 text-[15px] font-medium [overflow-wrap:anywhere] ${todo.done ? "line-through text-[var(--muted)]" : ""}`}>{todo.text}</span>
                    <button onClick={() => deleteTodo(todo.id)} aria-label={`Hapus ${todo.text}`} className="shrink-0 rounded-xl p-2 text-[var(--muted)] transition hover:bg-[var(--pink)]/10 hover:text-[var(--pink)]"><Trash2 size={18} /></button>
                  </div>
                ))}
              </div>

              {todos.length > 0 && (
                <div className="mt-5 rounded-2xl bg-[var(--surface-2)] p-4">
                  <div className="flex justify-between text-xs font-bold text-[var(--muted)]"><span>Progress</span><span>{doneCount}/{todos.length} selesai</span></div>
                  <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-[var(--bg)]"><div className="h-full bg-[var(--cyan)] transition-all duration-500" style={{ width: `${todos.length ? (doneCount / todos.length) * 100 : 0}%` }} /></div>
                  <p className="mt-3 text-sm font-bold">{remaining === 0 ? "🎉 Semua beres! Kamu keren." : `${remaining} tugas lagi. Satu-satu aja, pelan-pelan.`}</p>
                </div>
              )}
            </section>
          )}
        </main>

        <div className="mt-4 grid grid-cols-3 gap-2 text-center text-xs text-[var(--muted)]">
          <div className="rounded-2xl border border-[var(--line)] bg-[var(--surface)] p-3"><Zap className="mx-auto mb-1 text-[var(--primary)]" size={16} /><strong className="block text-sm text-[var(--text)]">Refleks</strong>Timer & event</div>
          <div className="rounded-2xl border border-[var(--line)] bg-[var(--surface)] p-3"><Palette className="mx-auto mb-1 text-[var(--violet)]" size={16} /><strong className="block text-sm text-[var(--text)]">Warna</strong>Logika HEX</div>
          <div className="rounded-2xl border border-[var(--line)] bg-[var(--surface)] p-3"><ListTodo className="mx-auto mb-1 text-[var(--cyan)]" size={16} /><strong className="block text-sm text-[var(--text)]">Fokus</strong>List & state</div>
        </div>

        <footer className="mt-6 border-t border-[var(--line)] pt-4 text-center">
          <p className="text-xs leading-relaxed text-[var(--muted)]">dibuat untuk belajar JS: DOM, event, timer, localStorage</p>
          <p className="mt-1 text-[11px] text-[var(--muted)]">sagi-des · Experiment #2 · main dulu, belajar kemudian</p>
        </footer>
      </div>
    </div>
  );
}
