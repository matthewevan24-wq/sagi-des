import React, { useEffect, useMemo, useRef, useState } from 'react';
import './index.css';
import { Trophy, RotateCcw, Plus, Spade, Heart, Diamond, Club, Coins, Crown, Sparkles, ChevronRight, ShieldCheck, Zap, MessageSquareText } from 'lucide-react';

type Suit = '♠' | '♥' | '♦' | '♣';
type CardT = { rank: string; value: number; suit: Suit };
type Phase = 'preflop' | 'flop' | 'turn' | 'river' | 'showdown';
type PlayerState = { id: number; name: string; short: string; chips: number; hand: CardT[]; bet: number; folded: boolean; allIn: boolean; isBot: boolean; isWinner?: boolean; handName?: string };
type GS = { players: PlayerState[]; community: CardT[]; deck: CardT[]; phase: Phase; pot: number; currentBet: number; turn: number; acted: boolean[]; round: number; dealer: number; stage: 'ready' | 'betting' | 'showdown' | 'over'; winners: number[]; lastAction: string; showdownInfo: string };

const RANKS = ['2','3','4','5','6','7','8','9','10','J','Q','K','A'];
const VALUES: Record<string, number> = { '2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,'10':10,'J':11,'Q':12,'K':13,'A':14 };
const SUITS: Suit[] = ['♠','♥','♦','♣'];
const HAND_NAMES = ['High Card','Pair','Two Pair','Three of a Kind','Straight','Flush','Full House','Four of a Kind','Straight Flush','Royal Flush'];

function newDeck(): CardT[] {
  const d: CardT[] = [];
  for (const s of SUITS) for (const r of RANKS) d.push({ rank: r, value: VALUES[r], suit: s });
  for (let i = d.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [d[i], d[j]] = [d[j], d[i]]; }
  return d;
}
function eval5(cards: CardT[]): [number, number[]] {
  const vals = cards.map(c => c.value).sort((a,b) => b-a);
  const flush = cards.every(c => c.suit === cards[0].suit);
  const counts = new Map<number, number>(); vals.forEach(v => counts.set(v, (counts.get(v)||0)+1));
  const groups = [...counts.entries()].sort((a,b) => b[1]-a[1] || b[0]-a[0]);
  const uniq = [...new Set(vals)].sort((a,b)=>b-a);
  let straightHigh = 0;
  if (uniq.length===5) {
    if (uniq[0]-uniq[4]===4) straightHigh = uniq[0];
    if (JSON.stringify(uniq)==='[14,5,4,3,2]') straightHigh = 5;
  }
  if (flush && straightHigh) return straightHigh===14 ? [9,[14]] : [8,[straightHigh]];
  if (groups[0][1]===4) return [7,[groups[0][0], groups[1][0]]];
  if (groups[0][1]===3 && groups[1][1]===2) return [6,[groups[0][0], groups[1][0]]];
  if (flush) return [5, vals];
  if (straightHigh) return [4,[straightHigh]];
  if (groups[0][1]===3) return [3,[groups[0][0], ...groups.slice(1).map(g=>g[0]).sort((a,b)=>b-a)]];
  if (groups[0][1]===2 && groups[1][1]===2) { const pairs=[groups[0][0],groups[1][0]].sort((a,b)=>b-a); return [2,[...pairs, groups[2][0]]]; }
  if (groups[0][1]===2) return [1,[groups[0][0], ...groups.slice(1).map(g=>g[0]).sort((a,b)=>b-a)]];
  return [0, vals];
}
function bestOf7(cards: CardT[]): { cat:number; tie:number[]; name:string } {
  let best: [number, number[]] = [-1, []];
  for (let a=0;a<cards.length;a++) for (let b=a+1;b<cards.length;b++) for (let c=b+1;c<cards.length;c++) for (let d=c+1;d<cards.length;d++) for (let e=d+1;e<cards.length;e++) {
    const cur = eval5([cards[a],cards[b],cards[c],cards[d],cards[e]]);
    if (cur[0]>best[0] || (cur[0]===best[0] && JSON.stringify(cur[1])>JSON.stringify(best[1]))) best=cur;
  }
  return { cat:best[0], tie:best[1], name:HAND_NAMES[best[0]] };
}
function bestOfAvailable(hand: CardT[], community: CardT[]): { cat:number; name:string } {
  const all=[...hand,...community];
  if (all.length<5) {
    if (hand[0]?.value===hand[1]?.value) return {cat:1,name:'Pair'};
    const hi=Math.max(hand[0]?.value||0,hand[1]?.value||0);
    return {cat:0,name: hi>=13 ? 'High Card — Kartu Tinggi' : 'High Card'};
  }
  return bestOf7(all);
}
function compareHands(a:{cat:number;tie:number[]}, b:{cat:number;tie:number[]}): number {
  if (a.cat!==b.cat) return a.cat-b.cat;
  for (let i=0;i<Math.max(a.tie.length,b.tie.length);i++) { const d=(a.tie[i]||0)-(b.tie[i]||0); if(d) return d; }
  return 0;
}
function SuitIcon({suit, size=16}:{suit:Suit; size?:number}) {
  if (suit==='♠') return <Spade size={size} fill="currentColor" />;
  if (suit==='♥') return <Heart size={size} fill="currentColor" />;
  if (suit==='♦') return <Diamond size={size} fill="currentColor" />;
  return <Club size={size} fill="currentColor" />;
}
function PlayingCard({card, faceDown, small, delay=0, dim}: {card?: CardT; faceDown?: boolean; small?: boolean; delay?: number; dim?: boolean}) {
  const w = small ? 'w-[42px] h-[60px] sm:w-[48px] sm:h-[68px]' : 'w-[54px] h-[76px] sm:w-[62px] sm:h-[88px]';
  if (faceDown) return <div className={`${w} card-back rounded-[10px] shrink-0 deal flex items-center justify-center`} style={{animationDelay:`${delay}ms`}}><div className="w-[70%] h-[70%] border border-[#f5d67a]/70 rounded-md grid place-items-center"><span className="font-display text-[#f5d67a] text-lg">S</span></div></div>;
  if (!card) return <div className={`${w} bg-white/10 border border-dashed border-white/20 rounded-[10px] shrink-0`} />;
  const red = card.suit==='♥'||card.suit==='♦';
  return <div className={`${w} poker-card shrink-0 deal ${dim?'opacity-60':''} flex flex-col justify-between p-[5px] sm:p-[7px]`} style={{animationDelay:`${delay}ms`}}>
    <div className={`leading-none ${red?'text-[#c9182e]':'text-[#171717]'} font-extrabold text-[13px] sm:text-[15px] flex flex-col items-start`}><span>{card.rank}</span><SuitIcon suit={card.suit} size={12} /></div>
    <div className={`self-center ${red?'text-[#c9182e]':'text-[#171717]'}`}><SuitIcon suit={card.suit} size={small?22:30} /></div>
    <div className={`leading-none self-end rotate-180 ${red?'text-[#c9182e]':'text-[#171717]'} font-extrabold text-[13px] sm:text-[15px] flex flex-col items-start`}><span>{card.rank}</span><SuitIcon suit={card.suit} size={12} /></div>
  </div>;
}
function Chip({amount, label}:{amount:number; label?:string}) {
  return <div className="flex items-center gap-1.5"><div className="w-7 h-7 rounded-full bg-[#e8b84b] border-[3px] border-dashed border-white shadow-md grid place-items-center text-[10px] font-black text-[#3a2700] chip-float">◆</div><div><div className="text-[10px] uppercase tracking-widest text-[#a9bfae]">{label||'Pot'}</div><div className="font-extrabold text-[#f5d67a] leading-none">{amount.toLocaleString('id-ID')}</div></div></div>;
}

const initialPlayers = (chips=1000): PlayerState[] => [
  {id:0,name:'Kamu',short:'K',chips,hand:[],bet:0,folded:false,allIn:false,isBot:false},
  {id:1,name:'Bot Raka',short:'R',chips,hand:[],bet:0,folded:false,allIn:false,isBot:true},
  {id:2,name:'Bot Denz',short:'D',chips,hand:[],bet:0,folded:false,allIn:false,isBot:true},
];

export default function App(){
  const [gs,setGs]=useState<GS>({players:initialPlayers(),community:[],deck:[],phase:'preflop',pot:0,currentBet:0,turn:-1,acted:[false,false,false],round:1,dealer:0,stage:'ready',winners:[],lastAction:'Meja siap. Mulai ronde pertama untuk membagikan kartu.',showdownInfo:''});
  const [log,setLog]=useState<string[]>(['🎲 Selamat datang di SAGI POKER — Texas Hold\'em.','🃏 Kamu duduk bersama Bot Raka dan Bot Denz.','💰 Setiap pemain membawa 1.000 chip virtual.']);
  const [showLog,setShowLog]=useState(false);
  const [celebrate,setCelebrate]=useState(false);
  const gsRef=useRef(gs); gsRef.current=gs;
  const timerRef=useRef<number|undefined>(undefined);

  const pushLog=(s:string)=> setLog(prev=>[`${new Date().toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'})} • ${s}`,...prev].slice(0,60));
  const me=gs.players[0];
  const callAmount=Math.max(0, gs.currentBet - me.bet);
  const canCheck=callAmount===0;
  const active=gs.players.filter(p=>!p.folded);
  const playerBest=useMemo(()=> me.hand.length===2 ? bestOfAvailable(me.hand, gs.community) : null,[me.hand, gs.community]);

  function startRound(round:number, dealer:number, keepPlayers?:PlayerState[]){
    const base=keepPlayers || initialPlayers();
    const players: PlayerState[] = base.map(p=>({...p,hand:[],bet:0,folded:false,allIn:false,isWinner:false,handName:undefined}));
    const deck=newDeck();
    players.forEach(p=>{ p.hand=[deck.pop()!, deck.pop()!]; });
    const sb=(dealer+1)%3, bb=(dealer+2)%3;
    players[sb].chips-=10; players[sb].bet=10;
    players[bb].chips-=20; players[bb].bet=20;
    const first=(bb+1)%3;
    pushLog(`— RONDE ${round} — Dealer: ${players[dealer].name}. Small Blind 10 • Big Blind 20.`);
    pushLog(`${players[sb].name} pasang Small Blind 10. ${players[bb].name} pasang Big Blind 20.`);
    setCelebrate(false);
    setGs({players,community:[],deck,phase:'preflop',pot:30,currentBet:20,turn:first,acted:[false,false,false],round,dealer,stage:'betting',winners:[],lastAction:`Giliran ${players[first].name}.`,showdownInfo:''});
  }

  function endHandByFold(winnerIdx:number, reason:string){
    const g=gsRef.current;
    const players=g.players.map(p=>({...p, isWinner:p.id===winnerIdx}));
    players[winnerIdx].chips+=g.pot;
    pushLog(`🏆 ${players[winnerIdx].name} menang ${g.pot.toLocaleString('id-ID')} chip — ${reason}`);
    if(winnerIdx===0) setCelebrate(true);
    setGs({...g,players,pot:0,currentBet:0,turn:-1,stage:'over',winners:[winnerIdx],lastAction:`${players[winnerIdx].name} memenangkan pot.`,showdownInfo:`${players[winnerIdx].name} menang karena ${reason.toLowerCase()}.`});
  }

  function doShowdown(g:GS){
    const contenders=g.players.filter(p=>!p.folded);
    const evals=contenders.map(p=>({...p, result:bestOf7([...p.hand,...g.community])}));
    let best=evals[0]; evals.forEach(e=>{ if(compareHands(e.result,best.result)>0) best=e; });
    const winners=evals.filter(e=>compareHands(e.result,best.result)===0);
    const share=Math.floor(g.pot/winners.length); const remainder=g.pot-share*winners.length;
    const players=g.players.map(p=>{
      const ev=evals.find(x=>x.id===p.id);
      const win=winners.find(w=>w.id===p.id);
      return {...p, handName:ev?ev.result.name:undefined, isWinner:!!win, chips:p.chips + (win ? share + (winners[0].id===p.id?remainder:0) : 0)};
    });
    const names=winners.map(w=>w.name).join(' & ');
    pushLog(`🃏 SHOWDOWN — ${contenders.map(c=>`${c.name}: ${c.result.name}`).join(' • ')}`);
    pushLog(`🏆 ${names} menang ${g.pot.toLocaleString('id-ID')} chip ${winners.length>1?'(pot dibagi)':''}.`);
    if(winners.some(w=>w.id===0)) setCelebrate(true);
    setGs({...g,players,pot:0,currentBet:0,turn:-1,stage:'showdown',winners:winners.map(w=>w.id),lastAction:`Showdown! ${names} menang.`,showdownInfo:`${names} menang dengan ${best.result.name}.`});
  }

  function advanceRound(g:GS): GS {
    // collect bets into pot (they are already counted via pot increments on actions? we keep pot separate, bets are per-round)
    // In this engine pot holds total including current street; on street change we reset bets but keep pot.
    const streetBets=g.players.reduce((s,p)=>s+p.bet,0);
    const players=g.players.map(p=>({...p,bet:0}));
    let phase:Phase=g.phase; let community=[...g.community]; let deck=[...g.deck];
    if(g.phase==='preflop'){ phase='flop'; community.push(deck.pop()!,deck.pop()!,deck.pop()!); pushLog('🃏 FLOP dibuka: 3 kartu community.'); }
    else if(g.phase==='flop'){ phase='turn'; community.push(deck.pop()!); pushLog('🃏 TURN dibuka: 1 kartu community.'); }
    else if(g.phase==='turn'){ phase='river'; community.push(deck.pop()!); pushLog('🃏 RIVER dibuka: kartu community terakhir.'); }
    else { return g; }
    const firstActive=(g.dealer+1)%3;
    let turn=firstActive; for(let i=0;i<3;i++){ const idx=(firstActive+i)%3; if(!players[idx].folded && !players[idx].allIn){ turn=idx; break; } }
    return {...g,players,community,deck,phase,pot:g.pot,currentBet:0,turn,acted:[false,false,false],lastAction:`${phase.toUpperCase()} — giliran ${players[turn].name}.`};
  }

  function afterAction(g:GS): GS {
    const actives=g.players.filter(p=>!p.folded);
    if(actives.length===1){ return g; }
    const canAct=actives.filter(p=>!p.allIn);
    const betsMatched=actives.every(p=>p.allIn || p.bet===g.currentBet);
    const allActed=actives.every((p,i)=>p.allIn || g.acted[p.id]);
    if(canAct.length<=1 && betsMatched){
      // fast forward through remaining streets
      let cur:GS={...g,acted:[true,true,true]};
      // if already river, showdown handled by caller; if not, advance repeatedly
      while(cur.phase!=='river'){
        cur=advanceRound(cur);
        // if after advancing everyone is all-in, continue loop
        if(cur.players.filter(p=>!p.folded && !p.allIn).length>1) break;
        cur={...cur,acted:[true,true,true]};
      }
      if(cur.phase==='river' && cur.players.filter(p=>!p.folded && !p.allIn).length<=1){
        return {...cur, stage:'betting'};
      }
      return cur;
    }
    if(betsMatched && allActed){
      if(g.phase==='river') return {...g, stage:'betting'};
      return advanceRound(g);
    }
    // next turn
    let next=g.turn;
    for(let i=1;i<=3;i++){ const idx=(g.turn+i)%3; const p=g.players[idx]; if(!p.folded && !p.allIn && !g.acted[idx]){ next=idx; break; } if(!p.folded && !p.allIn){ next=idx; break; } }
    // if next loop finds no unacted, fallback to first not acted / first active
    const hasUnacted=g.players.some(p=>!p.folded && !p.allIn && !g.acted[p.id]);
    if(!hasUnacted && betsMatched){
      if(g.phase==='river') return {...g, stage:'betting'};
      return advanceRound(g);
    }
    return {...g,turn:next,lastAction:`Giliran ${g.players[next].name}.`};
  }

  function applyAction(g:GS, idx:number, action:'check'|'call'|'raise'|'fold'|'allin'): GS {
    const players=g.players.map(p=>({...p}));
    const p=players[idx];
    let acted=[...g.acted]; acted[idx]=true;
    let pot=g.pot; let currentBet=g.currentBet; let msg='';
    if(action==='fold'){ p.folded=true; msg=`${p.name} FOLD.`; pushLog(`❌ ${p.name} fold — keluar dari ronde ini.`); }
    else if(action==='check'){ msg=`${p.name} CHECK.`; pushLog(`✔️ ${p.name} check.`); }
    else if(action==='call'){ const amt=Math.min(p.chips, currentBet-p.bet); p.chips-=amt; p.bet+=amt; pot+=amt; msg=`${p.name} CALL ${amt}.`; pushLog(`📞 ${p.name} call ${amt.toLocaleString('id-ID')} chip.`); }
    else if(action==='raise'){ const toPut=(currentBet-p.bet)+100; const amt=Math.min(p.chips,toPut); p.chips-=amt; p.bet+=amt; pot+=amt; currentBet=p.bet; acted=[false,false,false]; acted[idx]=true; msg=`${p.name} RAISE +100.`; pushLog(`🔥 ${p.name} raise +100 chip (taruhan jadi ${currentBet}).`); }
    else if(action==='allin'){ const amt=p.chips; p.chips=0; p.bet+=amt; pot+=amt; if(p.bet>currentBet){ currentBet=p.bet; acted=[false,false,false]; acted[idx]=true; } p.allIn=true; msg=`${p.name} ALL-IN ${amt}!`; pushLog(`🚀 ${p.name} ALL-IN ${amt.toLocaleString('id-ID')} chip!`); }
    if(p.chips===0 && !p.folded && action!=='fold') p.allIn=true;
    let next:GS={...g,players,pot,currentBet,acted,lastAction:msg};
    const actives=players.filter(x=>!x.folded);
    if(actives.length===1){ return {...next, stage:'betting'}; }
    if(next.phase==='river' && actives.every(x=>x.allIn || x.bet===next.currentBet) && actives.every(x=>x.allIn || next.acted[x.id])){
      return {...next, stage:'betting'};
    }
    return afterAction(next);
  }

  function handlePlayer(action:'check'|'call'|'raise'|'fold'|'allin'){
    const g=gsRef.current;
    if(g.stage!=='betting' || g.turn!==0) return;
    const next=applyAction(g,0,action);
    const actives=next.players.filter(p=>!p.folded);
    if(actives.length===1){ setGs(next); setTimeout(()=>endHandByFold(actives[0].id,'semua lawan fold'),350); return; }
    if(next.phase==='river' && actives.every(p=>p.allIn || p.bet===next.currentBet) && actives.every(p=>p.allIn || next.acted[p.id])){
      setGs(next); setTimeout(()=>doShowdown(gsRef.current),600); return;
    }
    // if fast-forward left us at river with no one to act, showdown
    if(next.phase==='river' && next.players.filter(p=>!p.folded && !p.allIn).length<=1 && actives.every(p=>p.allIn || p.bet===next.currentBet)){
      // only if all have acted or are all-in
      setGs(next); setTimeout(()=>doShowdown(gsRef.current),600); return;
    }
    setGs(next);
  }

  function botDecide(g:GS, idx:number){
    const p=g.players[idx];
    const callAmt=g.currentBet-p.bet;
    const strength = g.phase==='preflop'
      ? (p.hand[0].value===p.hand[1].value ? 0.85 : (Math.max(p.hand[0].value,p.hand[1].value)>=12 ? 0.65 : Math.random()*0.45))
      : bestOfAvailable(p.hand,g.community).cat/9 + Math.random()*0.25;
    const r=Math.random();
    if(callAmt===0){
      if(strength>0.72 && p.chips>150 && r>0.45) return 'raise' as const;
      if(strength>0.55 && p.chips>120 && r>0.78) return 'raise' as const;
      return 'check' as const;
    }
    if(callAmt>=p.chips) return strength>0.35 ? 'allin' as const : 'fold' as const;
    if(strength>0.68 && r>0.5 && p.chips>callAmt+100) return 'raise' as const;
    if(strength>0.32 || r>0.42) return 'call' as const;
    return 'fold' as const;
  }

  useEffect(()=>{
    if(gs.stage!=='betting') return;
    const cur=gs.players[gs.turn];
    if(!cur || !cur.isBot || cur.folded || cur.allIn) return;
    // if betting round already complete, go to showdown / next street is handled in afterAction; but guard
    window.clearTimeout(timerRef.current);
    timerRef.current=window.setTimeout(()=>{
      const g=gsRef.current;
      if(g.stage!=='betting' || g.turn!==cur.id) return;
      const action=botDecide(g,cur.id);
      const next=applyAction(g,cur.id,action);
      const actives=next.players.filter(p=>!p.folded);
      if(actives.length===1){ setGs(next); setTimeout(()=>endHandByFold(actives[0].id,'semua lawan fold'),350); return; }
      if(next.phase==='river' && actives.every(p=>p.allIn || p.bet===next.currentBet) && actives.every(p=>p.allIn || next.acted[p.id])){
        setGs(next); setTimeout(()=>doShowdown(gsRef.current),600); return;
      }
      setGs(next);
    }, 900);
    return ()=>window.clearTimeout(timerRef.current);
  },[gs.stage, gs.turn, gs.round, gs.phase, gs.currentBet]);

  // Auto-showdown when fast-forward reaches river with no actors
  useEffect(()=>{
    if(gs.stage==='betting' && gs.phase==='river'){
      const actives=gs.players.filter(p=>!p.folded);
      if(actives.length>1 && gs.players.filter(p=>!p.folded && !p.allIn).length===0){
        const t=window.setTimeout(()=>doShowdown(gsRef.current),700); return ()=>window.clearTimeout(t);
      }
    }
  },[gs.stage, gs.phase, gs.turn]);

  const playerOut = me.chips===0 && (gs.stage==='over'||gs.stage==='showdown'||gs.stage==='ready');
  const botZero = gs.players.filter(p=>p.isBot && p.chips===0 && (gs.stage==='over'||gs.stage==='showdown'));

  function nextRound(){
    let players=gs.players.map(p=>({...p}));
    // bot top-up if broke
    players=players.map(p=> p.isBot && p.chips===0 ? {...p,chips:1000} : p);
    if(players.some(p=>p.isBot && p.chips===0)) pushLog('Bot kehabisan chip dan top-up 1.000 chip.');
    const nextDealer=(gs.dealer+1)%3;
    startRound(gs.round+1,nextDealer,players);
  }
  function newGame(){ setLog(['🎲 Game baru dimulai. Semua chip dikembalikan ke 1.000.']); startRound(1,0,initialPlayers()); }
  function resetChips(){
    const players=gs.players.map(p=> p.id===0 ? {...p,chips:1000} : p);
    pushLog('🔄 Chip kamu direset ke 1.000.');
    startRound(gs.round+1,(gs.dealer+1)%3,players);
  }

  const phaseLabel:Record<Phase,string>={preflop:'Pre-Flop',flop:'Flop',turn:'Turn',river:'River',showdown:'Showdown'};
  const confettiColors=['#e8b84b','#f5d67a','#e83a4d','#2ecc71','#ffffff','#ff8a00'];

  return <div data-safe-area-inset-root className="min-h-[100dvh] bg-[var(--bg)] text-[var(--text)] overflow-x-clip" style={{boxSizing:'border-box',paddingTop:'var(--safe-area-inset-top)'}}>
    {celebrate && <div className="pointer-events-none fixed inset-0 z-50 overflow-hidden">{Array.from({length:42}).map((_,i)=><span key={i} className="confetti absolute top-0 block w-2.5 h-4 rounded-[2px]" style={{left:`${(i*23)%100}%`,background:confettiColors[i%6],animationDelay:`${(i%12)*0.12}s`,transform:`rotate(${i*17}deg)`}} />)}</div>}

    <header data-safe-area-sticky-top className="sticky z-30 border-b border-[#2f4a35] bg-[#07120c]/95 backdrop-blur" style={{top:'var(--safe-area-inset-top)'}}>
      <div className="mx-auto max-w-[1280px] px-3 sm:px-5 py-3 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-gradient-to-br from-[#f5d67a] to-[#9a7420] grid place-items-center text-[#1a1200] font-display font-bold text-xl shadow-lg shrink-0">S</div>
          <div className="min-w-0"><h1 className="font-display font-bold leading-none text-[clamp(1.15rem,4vw,1.7rem)] tracking-wide"><span className="gold-text">SAGI POKER</span></h1><p className="text-[11px] sm:text-xs tracking-[0.22em] text-[#a9bfae]">TEXAS HOLD'EM • CASINO PREMIUM</p></div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <div className="hidden sm:flex items-center gap-1.5 rounded-full border border-[#2f4a35] bg-[#0d1f15] px-3 py-1.5 text-sm"><Coins size={15} className="text-[#e8b84b]"/><b>{me.chips.toLocaleString('id-ID')}</b><span className="text-[#a9bfae] text-xs">chip</span></div>
          <button onClick={newGame} className="flex items-center gap-1.5 rounded-full bg-[#e8b84b] px-3 sm:px-4 py-2 text-xs sm:text-sm font-extrabold text-[#221a00] shadow hover:brightness-110 active:scale-95 transition"><RotateCcw size={15}/> New Game</button>
        </div>
      </div>
    </header>

    <main className="mx-auto max-w-[1280px] px-3 sm:px-5 py-4 sm:py-6">
      <div className="grid lg:grid-cols-[minmax(0,1fr)_320px] gap-4 items-start">
        <section>
          <div className="flex flex-wrap items-center gap-2 mb-3">
            <span className="rounded-full bg-[#12291c] border border-[#2f4a35] px-3 py-1 text-xs font-bold">RONDE {gs.round}</span>
            <span className="rounded-full bg-[#e8b84b] text-[#221a00] px-3 py-1 text-xs font-extrabold">{phaseLabel[gs.phase].toUpperCase()}</span>
            <span className="rounded-full bg-[#12291c] border border-[#2f4a35] px-3 py-1 text-xs text-[#a9bfae]">Dealer: <b className="text-white">{gs.players[gs.dealer].name}</b></span>
            <span className="rounded-full bg-[#12291c] border border-[#2f4a35] px-3 py-1 text-xs text-[#a9bfae] hidden sm:inline">Blind 10 / 20</span>
          </div>

          {/* TABLE */}
          <div className="wood rounded-[999px] p-2.5 sm:p-3.5">
            <div className="felt relative rounded-[999px] min-h-[480px] sm:min-h-[520px] px-3 py-5 overflow-hidden">
              <div className="absolute inset-x-0 top-3 text-center pointer-events-none"><span className="font-display text-[#f5d67a]/25 tracking-[0.35em] text-xs sm:text-sm">★ SAGI POKER ★</span></div>

              {/* Bots */}
              <div className="absolute top-[58px] sm:top-[64px] left-[6%] sm:left-[10%] z-10">
                <Seat p={gs.players[1]} gs={gs} showCards={gs.stage==='showdown'} dealer={gs.dealer===1} />
              </div>
              <div className="absolute top-[58px] sm:top-[64px] right-[6%] sm:right-[10%] z-10">
                <Seat p={gs.players[2]} gs={gs} showCards={gs.stage==='showdown'} dealer={gs.dealer===2} />
              </div>

              {/* Center */}
              <div className="absolute left-1/2 top-[46%] -translate-x-1/2 -translate-y-1/2 w-full max-w-[430px] px-2 text-center">
                <div className="flex justify-center mb-3"><div className="rounded-full border border-[#f5d67a]/40 bg-black/25 px-4 py-1.5"><Chip amount={gs.pot} /></div></div>
                <div className="flex justify-center gap-1.5 sm:gap-2 min-h-[88px] items-center">
                  {gs.community.length===0 ? Array.from({length:5}).map((_,i)=><PlayingCard key={i} />) : gs.community.map((c,i)=><PlayingCard key={i} card={c} delay={i*90} />)}
                  {gs.community.length>0 && gs.community.length<5 && Array.from({length:5-gs.community.length}).map((_,i)=><PlayingCard key={'e'+i} />)}
                </div>
                <p className="mt-3 text-[12px] sm:text-sm text-white/90 min-h-[20px] font-semibold [overflow-wrap:anywhere]">{gs.lastAction}</p>
                {gs.showdownInfo && <p className="pop mt-1 inline-flex items-center gap-1.5 rounded-full bg-[#f5d67a] text-[#221a00] px-3 py-1 text-xs font-extrabold"><Trophy size={13}/>{gs.showdownInfo}</p>}
              </div>

              {/* Player seat */}
              <div className="absolute bottom-[18px] left-1/2 -translate-x-1/2 w-full max-w-[420px] px-3">
                <div className="flex flex-col items-center gap-1.5">
                  <div className="flex gap-1.5 sm:gap-2">
                    {me.hand.length===2 ? me.hand.map((c,i)=><PlayingCard key={i} card={c} delay={i*120} />) : <><PlayingCard /><PlayingCard /></>}
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <div className={`flex items-center gap-2 rounded-full border px-3 py-1.5 bg-[#07120c]/85 backdrop-blur ${gs.winners.includes(0)?'winner border-[#f5d67a]':'border-white/15'}`}>
                      <span className="w-7 h-7 rounded-full bg-gradient-to-br from-[#f5d67a] to-[#9a7420] grid place-items-center text-[#221a00] font-black text-sm">K</span>
                      <span className="font-extrabold text-sm">Kamu</span>
                      <span className="flex items-center gap-1 text-[#f5d67a] text-sm font-bold"><Coins size={14}/>{me.chips.toLocaleString('id-ID')}</span>
                      {gs.dealer===0 && <span className="bg-white text-black text-[10px] font-black w-5 h-5 rounded-full grid place-items-center">D</span>}
                      {me.folded && <span className="text-[10px] bg-[#e83a4d] px-2 py-0.5 rounded-full font-bold">FOLD</span>}
                      {me.allIn && <span className="text-[10px] bg-[#e8b84b] text-black px-2 py-0.5 rounded-full font-bold">ALL-IN</span>}
                    </div>
                    {me.bet>0 && <span className="rounded-full bg-black/40 border border-[#f5d67a]/40 px-2.5 py-1 text-xs font-bold text-[#f5d67a]">Bet {me.bet}</span>}
                  </div>
                  {playerBest && gs.stage==='betting' && <p className="text-[11px] sm:text-xs text-[#f5d67a] font-bold bg-black/30 px-3 py-1 rounded-full">Kombinasimu: {playerBest.name}</p>}
                  {me.handName && gs.stage==='showdown' && <p className="text-xs text-[#f5d67a] font-bold bg-black/40 px-3 py-1 rounded-full">Kombinasimu: {me.handName}</p>}
                </div>
              </div>
            </div>
          </div>

          {/* CONTROLS */}
          <div className="mt-4 rounded-2xl border border-[#2f4a35] bg-[#0d1f15] p-3 sm:p-4">
            {gs.stage==='ready' ? <div className="flex flex-col sm:flex-row items-center justify-between gap-3"><div><p className="font-display font-bold text-lg gold-text">Siap bermain?</p><p className="text-sm text-[#a9bfae]">Kartu akan dibagikan ke kamu dan kedua bot.</p></div><button onClick={()=>startRound(1,0)} className="w-full sm:w-auto rounded-xl bg-[#e8b84b] px-6 py-3 font-extrabold text-[#221a00] flex items-center justify-center gap-2 hover:brightness-110 active:scale-95 transition"><Sparkles size={18}/> MULAI RONDE</button></div>
            : gs.stage==='betting' ? <div>
              <div className="flex flex-wrap items-center justify-between gap-2 mb-3"><p className="text-sm"><span className="text-[#a9bfae]">Giliran:</span> <b className={gs.turn===0?'text-[#f5d67a]':'text-white'}>{gs.players[gs.turn]?.name}</b> {gs.turn!==0 && <span className="text-[#a9bfae]">— bot sedang berpikir…</span>}</p><p className="text-sm">Taruhan saat ini: <b className="text-[#f5d67a]">{gs.currentBet}</b> • Kamu sudah bet: <b>{me.bet}</b></p></div>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                <button disabled={gs.turn!==0} onClick={()=>handlePlayer(canCheck?'check':'call')} className="rounded-xl bg-[#178251] disabled:opacity-40 disabled:cursor-not-allowed px-3 py-3.5 font-extrabold text-sm hover:brightness-110 active:scale-95 transition">{canCheck?'✓ CHECK':'📞 CALL '+callAmount}</button>
                <button disabled={gs.turn!==0 || me.chips<=callAmount} onClick={()=>handlePlayer('raise')} className="rounded-xl bg-[#e8b84b] text-[#221a00] disabled:opacity-40 px-3 py-3.5 font-extrabold text-sm hover:brightness-110 active:scale-95 transition flex items-center justify-center gap-1"><Plus size={16}/> RAISE +100</button>
                <button disabled={gs.turn!==0} onClick={()=>handlePlayer('fold')} className="rounded-xl bg-[#2a1518] border border-[#e83a4d]/60 text-[#ff8a95] px-3 py-3.5 font-extrabold text-sm hover:bg-[#3a1a1e] active:scale-95 transition">✕ FOLD</button>
                <button disabled={gs.turn!==0 || me.chips===0} onClick={()=>handlePlayer('allin')} className="rounded-xl bg-gradient-to-r from-[#ff3b30] to-[#ff8a00] px-3 py-3.5 font-extrabold text-sm hover:brightness-110 active:scale-95 transition flex items-center justify-center gap-1"><Zap size={16}/> ALL-IN {me.chips}</button>
                <button onClick={newGame} className="col-span-2 sm:col-span-1 rounded-xl border border-[#2f4a35] px-3 py-3.5 font-bold text-sm text-[#a9bfae] hover:text-white active:scale-95 transition">New Game</button>
              </div>
              <p className="mt-2.5 text-[11px] text-[#a9bfae]">Check = lanjut tanpa menambah taruhan (hanya jika tidak ada yang raise). Call = menyamakan taruhan. Raise +100 = menaikkan taruhan 100 chip.</p>
            </div>
            : <div className="flex flex-col sm:flex-row items-center justify-between gap-3"><div className="text-center sm:text-left"><p className="font-display font-bold text-lg gold-text flex items-center justify-center sm:justify-start gap-2"><Crown size={20}/> Ronde selesai</p><p className="text-sm text-[#a9bfae] [overflow-wrap:anywhere]">{gs.showdownInfo || gs.lastAction}</p>{playerOut && <p className="text-sm text-[#ff8a95] font-bold mt-1">Chip kamu habis. Reset untuk bermain lagi.</p>}</div><div className="flex gap-2 w-full sm:w-auto">{playerOut ? <button onClick={resetChips} className="flex-1 sm:flex-none rounded-xl bg-[#e8b84b] px-5 py-3 font-extrabold text-[#221a00] flex items-center justify-center gap-2"><RotateCcw size={16}/> RESET CHIP 1.000</button> : <button onClick={nextRound} className="flex-1 sm:flex-none rounded-xl bg-[#e8b84b] px-5 py-3 font-extrabold text-[#221a00] flex items-center justify-center gap-2">NEXT ROUND <ChevronRight size={16}/></button>}</div></div>}
          </div>

          {/* HAND RANKINGS */}
          <div className="mt-4 rounded-2xl border border-[#2f4a35] bg-[#0d1f15] p-4">
            <h2 className="font-display font-bold gold-text mb-2 flex items-center gap-2"><Trophy size={18}/> Urutan Kombinasi — Terkuat ke Terlemah</h2>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">{[...HAND_NAMES].reverse().map((h,i)=><div key={h} className={`rounded-xl border px-2.5 py-2 text-center ${i===0?'border-[#e8b84b] bg-[#e8b84b]/10': 'border-[#2f4a35]'}`}><div className="text-[10px] text-[#a9bfae]">{i===0?'TERKUAT':'#'+(10-i)}</div><div className="text-xs font-bold leading-tight [overflow-wrap:anywhere]">{h}</div></div>)}</div>
          </div>
        </section>

        {/* LOG */}
        <aside className="lg:sticky lg:top-[76px]">
          <div className="rounded-2xl border border-[#2f4a35] bg-[#0d1f15] overflow-hidden">
            <button onClick={()=>setShowLog(v=>!v)} className="w-full flex items-center justify-between px-4 py-3.5"><span className="font-display font-bold flex items-center gap-2"><MessageSquareText size={18} className="text-[#e8b84b]"/> LOG RONDE</span><span className="text-xs text-[#a9bfae] lg:hidden">{showLog?'Sembunyikan':'Lihat'}</span></button>
            <div className={`${showLog?'block':'hidden'} lg:block border-t border-[#2f4a35]`}>
              <div className="max-h-[380px] lg:max-h-[520px] overflow-y-auto no-scrollbar p-3 space-y-2">
                {log.map((l,i)=><p key={i} className={`text-[13px] leading-snug rounded-lg px-2.5 py-2 [overflow-wrap:anywhere] ${i===0?'bg-[#e8b84b]/10 border border-[#e8b84b]/30':'bg-[#12291c]'}`}>{l}</p>)}
              </div>
            </div>
          </div>
          <div className="mt-3 rounded-2xl border border-[#e8b84b]/30 bg-gradient-to-br from-[#1a2a12] to-[#0d1f15] p-4">
            <p className="font-display font-bold text-[#f5d67a] flex items-center gap-2"><ShieldCheck size={18}/> Cara Bermain</p>
            <ol className="mt-2 space-y-1.5 text-[13px] text-[#d8e2d5] leading-relaxed list-decimal list-inside"><li>Setiap pemain dapat 2 kartu tertutup.</li><li>Flop (3), Turn (1), River (1) dibuka bertahap.</li><li>Buat kombinasi 5 kartu terbaik dari 7 kartu.</li><li>Kombinasi tertinggi menang pot. Seri = pot dibagi.</li></ol>
          </div>
        </aside>
      </div>
    </main>
    <footer className="border-t border-[#2f4a35] mt-2"><div className="mx-auto max-w-[1280px] px-4 py-5 text-center text-xs sm:text-sm text-[#a9bfae]"><p className="font-display font-bold gold-text tracking-widest">SAGI POKER — TEXAS HOLD'EM</p><p className="mt-1">Hanya game hiburan, chip virtual, tanpa uang asli</p></div></footer>
  </div>;
}

function Seat({p,gs,showCards,dealer}:{p:PlayerState;gs:GS;showCards:boolean;dealer:boolean}){
  const show = showCards && !p.folded;
  return <div className="flex flex-col items-center gap-1">
    <div className={`flex gap-1 ${p.folded?'opacity-40 grayscale':''}`}>
      {p.hand.length===2 ? p.hand.map((c,i)=> show ? <PlayingCard key={i} card={c} small delay={i*100}/> : <PlayingCard key={i} faceDown small delay={i*100}/>) : <><PlayingCard small faceDown/><PlayingCard small faceDown/></>}
    </div>
    <div className={`flex items-center gap-1.5 rounded-full border px-2.5 py-1 bg-[#07120c]/85 backdrop-blur ${gs.winners.includes(p.id)?'winner border-[#f5d67a]':'border-white/15'}`}>
      <span className="w-6 h-6 rounded-full bg-[#274a35] grid place-items-center text-[11px] font-black">{p.short}</span>
      <span className="text-xs font-extrabold whitespace-nowrap">{p.name}</span>
      <span className="flex items-center gap-0.5 text-[11px] font-bold text-[#f5d67a]"><Coins size={12}/>{p.chips.toLocaleString('id-ID')}</span>
      {dealer && <span className="bg-white text-black text-[9px] font-black w-4 h-4 rounded-full grid place-items-center">D</span>}
      {p.folded && <span className="text-[9px] bg-[#e83a4d] px-1.5 py-0.5 rounded-full font-bold">FOLD</span>}
      {p.allIn && <span className="text-[9px] bg-[#e8b84b] text-black px-1.5 py-0.5 rounded-full font-bold">ALL-IN</span>}
    </div>
    {p.bet>0 && <span className="text-[10px] font-bold text-[#f5d67a] bg-black/40 px-2 py-0.5 rounded-full">Bet {p.bet}</span>}
    {p.handName && showCards && <span className="text-[10px] font-bold text-[#f5d67a] bg-black/50 px-2 py-0.5 rounded-full [overflow-wrap:anywhere]">{p.handName}</span>}
  </div>;
}
